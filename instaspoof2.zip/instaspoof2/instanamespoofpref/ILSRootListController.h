#import <Preferences/PSListController.h>

@interface ILSRootListController : PSListController

@end
